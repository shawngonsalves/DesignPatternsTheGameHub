package Constants;

public class BoardSize {

    public static final int WIDTH = 10;
    public static final int HEIGHT = 22;

}
