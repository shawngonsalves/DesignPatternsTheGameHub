package Game1;

public interface ObjectCreation_IF {
    public Object create();
}

