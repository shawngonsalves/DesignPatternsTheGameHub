import Game2.Game;

public class Minesweeper
{
    public static void main(String[] args) 
    {

        Game game = new Game();
        SingletonMinesweeper object2 = SingletonMinesweeper.getInstance();
        object2.show();
    }
}
